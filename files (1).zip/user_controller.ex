defmodule PhoenixChessWeb.UserController do
  use PhoenixChessWeb, :controller

  alias PhoenixChess.Accounts
  alias PhoenixChess.Games

  def profile(conn, _params) do
    user_id = conn.assigns.user_id
    user = Accounts.get_user(user_id)

    json(conn, %{
      id: user.id,
      username: user.username,
      avatar: user.avatar_url,
      elo: user.elo,
      wins: user.wins,
      losses: user.losses,
      draws: user.draws,
      is_online: user.is_online
    })
  end

  def games(conn, %{"limit" => limit}) do
    user_id = conn.assigns.user_id
    games = Games.get_user_games(user_id, String.to_integer(limit))

    json(conn, %{
      games: Enum.map(games, &format_game/1)
    })
  end

  def games(conn, _params) do
    games(conn, %{"limit" => "50"})
  end

  def stats(conn, _params) do
    user_id = conn.assigns.user_id
    user = Accounts.get_user(user_id)

    total_games = user.wins + user.losses + user.draws
    win_rate = if total_games > 0, do: Float.round(user.wins / total_games * 100, 2), else: 0

    json(conn, %{
      elo: user.elo,
      wins: user.wins,
      losses: user.losses,
      draws: user.draws,
      total_games: total_games,
      win_rate: win_rate
    })
  end

  def update_settings(conn, %{"theme" => theme}) do
    user_id = conn.assigns.user_id
    user = Accounts.get_user(user_id)

    {:ok, updated_user} = Accounts.update_user(user, %{theme: theme})

    json(conn, %{
      success: true,
      user: %{
        id: updated_user.id,
        theme: updated_user.theme
      }
    })
  end

  defp format_game(game) do
    %{
      id: game.id,
      game_id: game.game_id,
      white: game.white_user.username,
      black: game.black_user.username,
      game_type: game.game_type,
      result: game.result,
      status: game.status,
      created_at: game.inserted_at
    }
  end
end