defmodule PhoenixChess.Accounts.User do
  use Ecto.Schema
  import Ecto.Changeset

  schema "users" do
    field :username, :string
    field :email, :string
    field :avatar_url, :string
    field :password_hash, :string
    field :telegram_id, :string
    field :elo, :integer, default: 1600
    field :wins, :integer, default: 0
    field :losses, :integer, default: 0
    field :draws, :integer, default: 0
    field :is_online, :boolean, default: false
    field :last_seen, :utc_datetime
    field :theme, :string, default: "light"
    field :is_bot, :boolean, default: false

    has_many :games_as_white, PhoenixChess.Games.Game, foreign_key: :white_user_id
    has_many :games_as_black, PhoenixChess.Games.Game, foreign_key: :black_user_id
    has_many :messages, PhoenixChess.Chat.Message, foreign_key: :user_id

    timestamps()
  end

  def changeset(user, attrs) do
    user
    |> cast(attrs, [:username, :email, :avatar_url, :telegram_id, :elo, :theme, :is_online, :last_seen])
    |> validate_required([:username])
    |> unique_constraint(:username)
    |> unique_constraint(:email)
    |> unique_constraint(:telegram_id)
  end

  def password_changeset(user, attrs) do
    user
    |> cast(attrs, [:password_hash])
    |> validate_required([:password_hash])
  end
end