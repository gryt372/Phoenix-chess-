defmodule PhoenixChessWeb.LobbyChannel do
  use PhoenixWeb, :channel
  require Logger

  alias PhoenixChess.Games
  alias PhoenixChess.Accounts

  @impl true
  def join("lobby", %{"user_id" => user_id}, socket) do
    send(self(), {:after_join, user_id})
    {:ok, assign(socket, :user_id, user_id)}
  end

  @impl true
  def handle_info({:after_join, user_id}, socket) do
    # Send active games list
    active_games = Games.get_active_games(20)

    push(socket, "active_games", %{
      games: Enum.map(active_games, &format_game/1)
    })

    # Send leaderboard
    leaderboard = Accounts.get_leaderboard(10)

    push(socket, "leaderboard", %{
      players: leaderboard
    })

    broadcast_from!(socket, "user_online", %{
      user_id: user_id
    })

    {:noreply, socket}
  end

  def handle_in("create_game", %{
    "opponent_id" => opponent_id,
    "game_type" => game_type,
    "time_control" => time_control
  }, socket) do
    user_id = socket.assigns.user_id

    attrs = %{
      game_id: generate_game_id(),
      white_user_id: user_id,
      black_user_id: opponent_id,
      game_type: game_type,
      time_control: time_control,
      status: "active",
      white_clock: time_control,
      black_clock: time_control
    }

    case Games.create_game(attrs) do
      {:ok, game} ->
        broadcast!(socket, "game_created", %{
          game_id: game.game_id,
          white_id: user_id,
          black_id: opponent_id
        })

        {:reply, {:ok, %{game_id: game.game_id}}, socket}

      {:error, reason} ->
        {:reply, {:error, %{reason: inspect(reason)}}, socket}
    end
  end

  def handle_in("search_game", %{"game_type" => game_type, "time_control" => time_control}, socket) do
    user_id = socket.assigns.user_id
    
    # Store in matchmaking queue
    Phoenix.PubSub.subscribe(PhoenixChess.PubSub, "matchmaking:#{game_type}:#{time_control}")

    {:reply, :ok, assign(socket, :searching, true)}
  end

  def handle_in("cancel_search", _, socket) do
    {:reply, :ok, assign(socket, :searching, false)}
  end

  defp format_game(game) do
    %{
      game_id: game.game_id,
      white: %{username: game.white_user.username, elo: game.white_user.elo},
      black: %{username: game.black_user.username, elo: game.black_user.elo},
      game_type: game.game_type,
      status: game.status
    }
  end

  defp generate_game_id do
    :crypto.strong_rand_bytes(8)
    |> Base.encode16(case: :lower)
  end
end