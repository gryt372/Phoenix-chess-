defmodule PhoenixChess.Games.Game do
  use Ecto.Schema
  import Ecto.Changeset

  schema "games" do
    field :game_id, :string, unique: true
    field :status, :string, default: "pending"  # pending, active, completed, abandoned
    field :game_type, :string, default: "blitz"  # blitz, rapid, classical, bullet
    field :time_control, :integer, default: 300  # seconds
    field :increment, :integer, default: 0
    field :pgn, :string
    field :fen, :string
    field :move_list, {:array, :string}, default: []
    field :white_clock, :integer
    field :black_clock, :integer
    field :result, :string  # "1-0", "0-1", "1/2-1/2", nil
    field :winner_id, :integer
    field :termination, :string  # checkmate, resignation, timeout, draw, etc
    field :is_spectatable, :boolean, default: true
    field :created_at_timestamp, :utc_datetime

    belongs_to :white_user, PhoenixChess.Accounts.User, foreign_key: :white_user_id
    belongs_to :black_user, PhoenixChess.Accounts.User, foreign_key: :black_user_id
    has_many :moves, PhoenixChess.Games.Move
    has_many :messages, PhoenixChess.Chat.Message

    timestamps()
  end

  def changeset(game, attrs) do
    game
    |> cast(attrs, [
      :game_id, :status, :game_type, :time_control, :increment,
      :pgn, :fen, :move_list, :white_clock, :black_clock,
      :result, :winner_id, :termination, :is_spectatable,
      :created_at_timestamp, :white_user_id, :black_user_id
    ])
    |> validate_required([:game_id, :game_type, :time_control])
    |> validate_inclusion(:game_type, ["blitz", "rapid", "classical", "bullet", "arena"])
  end
end