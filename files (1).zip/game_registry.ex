defmodule PhoenixChess.GameRegistry do
  @moduledoc """
  Registry to manage active games and multiplayer connections
  """

  use GenServer

  def start_link(_opts) do
    GenServer.start_link(__MODULE__, %{}, name: __MODULE__)
  end

  def init(state) do
    {:ok, state}
  end

  def create_game(game_id, white_player, black_player) do
    game = PhoenixChess.Game.new(game_id, white_player, black_player)
    GenServer.call(__MODULE__, {:create, game_id, game})
  end

  def get_game(game_id) do
    GenServer.call(__MODULE__, {:get, game_id})
  end

  def update_game(game_id, game) do
    GenServer.cast(__MODULE__, {:update, game_id, game})
  end

  def handle_call({:create, game_id, game}, _from, state) do
    new_state = Map.put(state, game_id, game)
    {:reply, game, new_state}
  end

  def handle_call({:get, game_id}, _from, state) do
    game = Map.get(state, game_id)
    {:reply, game, state}
  end

  def handle_cast({:update, game_id, game}, state) do
    new_state = Map.put(state, game_id, game)
    {:noreply, new_state}
  end
end