defmodule PhoenixChess.Telegram.Auth do
  @moduledoc """
  Handles Telegram Mini App authentication
  """

  require Logger

  @telegram_token System.get_env("TELEGRAM_BOT_TOKEN", "")

  def verify_init_data(init_data_raw) do
    try do
      # Parse init data
      data_check_string = extract_data_check_string(init_data_raw)
      
      # Compute HMAC
      secret_key = compute_secret_key(@telegram_token)
      computed_hash = :crypto.mac(:hmac, :sha256, secret_key, data_check_string)
      |> Base.encode16(case: :lower)

      # Get hash from init data
      hash_from_init_data = extract_hash(init_data_raw)

      # Verify
      if computed_hash == hash_from_init_data do
        {:ok, parse_user_data(init_data_raw)}
      else
        {:error, "Invalid signature"}
      end
    rescue
      e ->
        Logger.error("Telegram auth error: #{inspect(e)}")
        {:error, "Authentication failed"}
    end
  end

  defp extract_data_check_string(init_data_raw) do
    init_data_raw
    |> String.split("&")
    |> Enum.reject(&String.starts_with?(&1, "hash="))
    |> Enum.sort()
    |> Enum.join("&")
  end

  defp extract_hash(init_data_raw) do
    init_data_raw
    |> String.split("&")
    |> Enum.find(&String.starts_with?(&1, "hash="))
    |> case do
      "hash=" <> hash -> hash
      _ -> ""
    end
  end

  defp compute_secret_key(token) do
    :crypto.mac(:hmac, :sha256, "WebAppData", token)
  end

  defp parse_user_data(init_data_raw) do
    init_data_raw
    |> URI.decode_query()
    |> Map.get("user")
    |> case do
      nil -> %{}
      user_json -> Jason.decode!(user_json)
    end
  end
end