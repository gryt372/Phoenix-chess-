import { Socket } from "phoenix"

let socket = null
let channel = null
let gameId = null
let selectedSquare = null
let validMoves = []
let gameMode = null
let moveHistory = []

export function initializeGame(mode) {
  gameMode = mode
  gameId = generateGameId()
  
  // Hide mode selection and show board
  document.querySelector('.game-modes').style.display = 'none'
  document.querySelector('#game-board-container').style.display = 'grid'
  
  // Initialize board
  initializeBoard()
  
  // Create WebSocket connection
  socket = new Socket("/socket", { params: { token: window.userToken } })
  socket.connect()
  
  channel = socket.channel(`game:${gameId}`, {})
  
  channel.on("game_state", payload => {
    updateBoard(payload.board)
    updateTurn(payload.turn)
  })
  
  channel.on("move_made", payload => {
    updateBoard(payload.board)
    updateTurn(payload.turn)
    addToMoveHistory(payload.from, payload.to, payload.ai_move)
    selectedSquare = null
    validMoves = []
    updateBoardUI()
  })
  
  channel.on("game_reset", payload => {
    updateBoard(payload.board)
    updateTurn(payload.turn)
    moveHistory = []
    document.querySelector('#move-list').innerHTML = ''
    selectedSquare = null
    validMoves = []
    updateBoardUI()
  })
  
  channel.on("game_started", payload => {
    updateBoard(payload.board)
    updateTurn(payload.turn)
    document.querySelector('#black-player').textContent = 
      payload.difficulty ? `AI (${payload.difficulty})` : 'Black Player'
  })
  
  channel.on("game_over", payload => {
    alert(`Game Over: ${payload.reason}`)
  })
  
  channel.join()
    .receive("ok", resp => {
      console.log("Joined successfully", resp)
      if (mode === 'pva') {
        channel.push("start_ai_game", { difficulty: 'medium' })
      }
    })
    .receive("error", resp => console.log("Unable to join", resp))
}

function initializeBoard() {
  const board = document.querySelector('#chessboard')
  board.innerHTML = ''
  
  for (let rank = 7; rank >= 0; rank--) {
    for (let file = 0; file < 8; file++) {
      const square = document.createElement('div')
      const isLight = (file + rank) % 2 === 0
      square.className = `square ${isLight ? 'light' : 'dark'}`
      square.id = `square-${file},${rank}`
      
      square.addEventListener('click', () => handleSquareClick(file, rank))
      
      board.appendChild(square)
    }
  }
  
  // Set player names
  document.querySelector('#white-player').textContent = gameMode === 'pva' ? 'You (White)' : 'White Player'
  document.querySelector('#black-player').textContent = gameMode === 'pva' ? 'AI (Medium)' : 'Black Player'
}

function updateBoard(boardState) {
  // Clear all pieces first
  document.querySelectorAll('.square').forEach(sq => {
    const piece = sq.querySelector('.piece')
    if (piece) piece.remove()
  })
  
  // Place pieces
  Object.entries(boardState).forEach(([square, piece]) => {
    if (piece) {
      const squareEl = document.querySelector(`#square-${square}`)
      if (squareEl) {
        const pieceEl = document.createElement('div')
        pieceEl.className = 'piece'
        pieceEl.textContent = getPieceUnicode(piece.color, piece.type)
        squareEl.appendChild(pieceEl)
      }
    }
  })
}

function updateBoardUI() {
  // Update selected square visual
  document.querySelectorAll('.square').forEach(sq => {
    sq.classList.remove('selected', 'valid-move')
  })
  
  if (selectedSquare) {
    const sq = document.querySelector(`#square-${selectedSquare}`)
    if (sq) sq.classList.add('selected')
  }
  
  validMoves.forEach(move => {
    const sq = document.querySelector(`#square-${move}`)
    if (sq) sq.classList.add('valid-move')
  })
}

function handleSquareClick(file, rank) {
  const squareCoord = `${file},${rank}`
  
  // If clicking on valid move, make the move
  if (validMoves.includes(squareCoord)) {
    makeMove(selectedSquare, squareCoord)
    return
  }
  
  // If clicking on a piece, select it
  const square = document.querySelector(`#square-${squareCoord}`)
  const hasPiece = square.querySelector('.piece')
  
  if (hasPiece) {
    selectedSquare = squareCoord
    // TODO: Calculate valid moves for the selected piece
    validMoves = []
    updateBoardUI()
  } else {
    selectedSquare = null
    validMoves = []
    updateBoardUI()
  }
}

function makeMove(from, to) {
  if (channel && from && to) {
    channel.push("move", { from, to })
      .receive("ok", resp => {
        console.log("Move accepted")
      })
      .receive("error", resp => {
        alert(`Invalid move: ${resp.reason}`)
      })
  }
}

function updateTurn(turn) {
  const turnText = turn === 'white' ? 'White to Move' : 'Black to Move'
  document.querySelector('#current-turn').textContent = turnText
}

function addToMoveHistory(from, to, aiMove = false) {
  const moveNum = Math.floor(moveHistory.length / 2) + 1
  const moveText = `${from} → ${to} ${aiMove ? '(AI)' : ''}`
  moveHistory.push(moveText)
  
  const moveList = document.querySelector('#move-list')
  const li = document.createElement('li')
  li.textContent = moveText
  li.className = 'latest'
  
  // Remove latest class from previous move
  document.querySelectorAll('#move-list li').forEach(item => {
    item.classList.remove('latest')
  })
  
  moveList.appendChild(li)
  moveList.scrollTop = moveList.scrollHeight
}

function getPieceUnicode(color, type) {
  const pieces = {
    white: {
      king: '♔',
      queen: '♕',
      rook: '♖',
      bishop: '♗',
      knight: '♘',
      pawn: '♙'
    },
    black: {
      king: '♚',
      queen: '♛',
      rook: '♜',
      bishop: '♝',
      knight: '♞',
      pawn: '♟'
    }
  }
  return pieces[color]?.[type] || ''
}

function generateGameId() {
  return Math.random().toString(36).substr(2, 9)
}

// Event listeners for buttons
document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('#pvp-btn')?.addEventListener('click', () => {
    initializeGame('pvp')
  })
  
  document.querySelector('#pva-btn')?.addEventListener('click', () => {
    initializeGame('pva')
  })
  
  document.querySelector('#reset-btn')?.addEventListener('click', () => {
    if (channel) {
      channel.push("reset_game")
    }
  })
  
  document.querySelector('#home-btn')?.addEventListener('click', () => {
    if (socket) {
      socket.disconnect()
    }
    location.reload()
  })
})

export { initializeGame }