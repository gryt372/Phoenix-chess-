defmodule PhoenixChessWeb.GameChannel do
  use PhoenixWeb, :channel
  require Logger
  
  alias PhoenixChess.Games
  alias PhoenixChess.Accounts
  alias PhoenixChess.AI.Engine
  alias PhoenixChess.Games.Game

  @impl true
  def join("game:" <> game_id, %{"user_id" => user_id}, socket) do
    game = Games.get_game_by_game_id(game_id)

    case game do
      nil ->
        {:error, %{reason: "Game not found"}}

      game ->
        send(self(), {:after_join, game, user_id})
        {:ok, 
          socket
          |> assign(:game_id, game_id)
          |> assign(:user_id, user_id)
          |> assign(:game, game)
        }
    end
  end

  @impl true
  def handle_info({:after_join, game, user_id}, socket) do
    # Determine if user is playing or spectating
    is_white = game.white_user_id == user_id
    is_black = game.black_user_id == user_id
    is_spectator = !is_white && !is_black

    # Send current game state to the joined user
    push(socket, "game_state", %{
      game_id: game.game_id,
      white_player: %{
        id: game.white_user.id,
        username: game.white_user.username,
        avatar: game.white_user.avatar_url,
        elo: game.white_user.elo,
        clock: game.white_clock
      },
      black_player: %{
        id: game.black_user.id,
        username: game.black_user.username,
        avatar: game.black_user.avatar_url,
        elo: game.black_user.elo,
        clock: game.black_clock
      },
      status: game.status,
      game_type: game.game_type,
      is_player: is_white || is_black,
      is_spectator: is_spectator,
      turn: if(rem(length(game.move_list), 2) == 0, do: "white", else: "black"),
      moves: game.move_list,
      fen: game.fen
    })

    # Broadcast that a user joined
    broadcast_from!(socket, "user_joined", %{
      user_id: user_id,
      is_spectator: is_spectator
    })

    {:noreply, socket}
  end

  @impl true
  def handle_in("move", %{"from" => from, "to" => to, "promotion" => promotion}, socket) do
    game_id = socket.assigns.game_id
    user_id = socket.assigns.user_id
    game = socket.assigns.game

    # Validate it's the correct player's turn
    turn = if rem(length(game.move_list), 2) == 0, do: :white, else: :black
    is_white = game.white_user_id == user_id
    is_black = game.black_user_id == user_id

    if (turn == :white && !is_white) || (turn == :black && !is_black) do
      {:reply, {:error, %{reason: "Not your turn"}}, socket}
    else
      # Validate move and update game
      case validate_and_execute_move(game, from, to, promotion) do
        {:ok, updated_game, move_data} ->
          Games.update_game(game, %{
            move_list: updated_game.move_list,
            fen: updated_game.fen,
            white_clock: updated_game.white_clock,
            black_clock: updated_game.black_clock,
            status: updated_game.status
          })

          broadcast!(socket, "move_made", move_data)

          # Check if game is over
          if updated_game.status == "completed" do
            broadcast!(socket, "game_over", %{
              result: updated_game.result,
              termination: updated_game.termination
            })
          end

          {:reply, :ok, assign(socket, :game, updated_game)}

        {:error, reason} ->
          {:reply, {:error, %{reason: reason}}, socket}
      end
    end
  end

  def handle_in("offer_draw", _, socket) do
    broadcast!(socket, "draw_offered", %{
      user_id: socket.assigns.user_id
    })
    {:reply, :ok, socket}
  end

  def handle_in("accept_draw", _, socket) do
    game = socket.assigns.game
    updated_game = %{game | status: "completed", result: "1/2-1/2", termination: "draw_agreed"}
    Games.update_game(game, Map.from_struct(updated_game))

    broadcast!(socket, "game_over", %{
      result: "1/2-1/2",
      termination: "draw_agreed"
    })

    {:reply, :ok, assign(socket, :game, updated_game)}
  end

  def handle_in("resign", _, socket) do
    game = socket.assigns.game
    user_id = socket.assigns.user_id

    is_white = game.white_user_id == user_id
    result = if is_white, do: "0-1", else: "1-0"
    winner_id = if is_white, do: game.black_user_id, else: game.white_user_id

    updated_game = %{
      game |
      status: "completed",
      result: result,
      winner_id: winner_id,
      termination: "resignation"
    }

    Games.update_game(game, Map.from_struct(updated_game))

    broadcast!(socket, "game_over", %{
      result: result,
      termination: "resignation",
      winner_id: winner_id
    })

    {:reply, :ok, assign(socket, :game, updated_game)}
  end

  def handle_in("send_message", %{"message" => message}, socket) do
    game_id = socket.assigns.game_id
    user_id = socket.assigns.user_id

    broadcast!(socket, "message", %{
      user_id: user_id,
      username: socket.assigns.username,
      message: message,
      timestamp: DateTime.utc_now()
    })

    {:reply, :ok, socket}
  end

  def handle_in("request_takeback", _, socket) do
    broadcast!(socket, "takeback_requested", %{
      user_id: socket.assigns.user_id
    })
    {:reply, :ok, socket}
  end

  defp validate_and_execute_move(game, from, to, promotion) do
    # TODO: Implement full chess move validation and execution
    {:ok, game, %{from: from, to: to, san: "move"}}
  end
end