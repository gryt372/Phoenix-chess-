defmodule PhoenixChess.Accounts do
  import Ecto.Query
  alias PhoenixChess.Repo
  alias PhoenixChess.Accounts.User

  def get_user(id), do: Repo.get(User, id)

  def get_user_by_username(username) do
    Repo.get_by(User, username: username)
  end

  def get_user_by_telegram_id(telegram_id) do
    Repo.get_by(User, telegram_id: telegram_id)
  end

  def get_user_by_email(email) do
    Repo.get_by(User, email: email)
  end

  def get_leaderboard(limit \\ 50) do
    from(u in User,
      where: u.is_bot == false,
      order_by: [desc: u.elo],
      limit: ^limit,
      select: %{
        id: u.id,
        username: u.username,
        avatar_url: u.avatar_url,
        elo: u.elo,
        wins: u.wins,
        losses: u.losses,
        draws: u.draws
      }
    )
    |> Repo.all()
  end

  def create_user_from_telegram(telegram_user) do
    attrs = %{
      username: telegram_user["username"] || "user_#{telegram_user["id"]}",
      telegram_id: to_string(telegram_user["id"]),
      avatar_url: telegram_user["photo_url"],
      email: telegram_user["username"] <> "@telegram.local"
    }

    %User{}
    |> User.changeset(attrs)
    |> Repo.insert(on_conflict: :replace_all, conflict_target: :telegram_id)
  end

  def create_user(attrs) do
    %User{}
    |> User.changeset(attrs)
    |> Repo.insert()
  end

  def update_user(user, attrs) do
    user
    |> User.changeset(attrs)
    |> Repo.update()
  end

  def update_user_stats(user_id, result) do
    user = get_user(user_id)
    
    attrs = case result do
      "1-0" -> %{wins: user.wins + 1}
      "0-1" -> %{losses: user.losses + 1}
      "1/2-1/2" -> %{draws: user.draws + 1}
      _ -> %{}
    end

    update_user(user, attrs)
  end

  def set_user_online(user_id, online) do
    user = get_user(user_id)
    update_user(user, %{is_online: online, last_seen: DateTime.utc_now()})
  end
end