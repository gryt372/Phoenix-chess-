defmodule PhoenixChess.Game.Board do
  @moduledoc """
  Manages the chess board state and piece positioning
  """

  defstruct squares: nil, move_history: [], turn: :white

  # Initial board setup
  def new do
    %__MODULE__{
      squares: setup_board(),
      move_history: [],
      turn: :white
    }
  end

  defp setup_board do
    # Initialize empty board (8x8)
    empty = Enum.reduce(0..63, %{}, fn i, acc -> Map.put(acc, i, nil) end)

    # Place white pieces
    empty
    |> place_pawns(:white, 8..15)
    |> place_rooks(:white, [0, 7])
    |> place_knights(:white, [1, 6])
    |> place_bishops(:white, [2, 5])
    |> place_queen(:white, 3)
    |> place_king(:white, 4)
    # Place black pieces
    |> place_pawns(:black, 48..55)
    |> place_rooks(:black, [56, 63])
    |> place_knights(:black, [57, 62])
    |> place_bishops(:black, [58, 61])
    |> place_queen(:black, 59)
    |> place_king(:black, 60)
  end

  defp place_pawns(board, color, squares) do
    Enum.reduce(squares, board, fn square, acc ->
      Map.put(acc, square, {:pawn, color})
    end)
  end

  defp place_rooks(board, color, squares) do
    Enum.reduce(squares, board, fn square, acc ->
      Map.put(acc, square, {:rook, color})
    end)
  end

  defp place_knights(board, color, squares) do
    Enum.reduce(squares, board, fn square, acc ->
      Map.put(acc, square, {:knight, color})
    end)
  end

  defp place_bishops(board, color, squares) do
    Enum.reduce(squares, board, fn square, acc ->
      Map.put(acc, square, {:bishop, color})
    end)
  end

  defp place_queen(board, color, square) do
    Map.put(board, square, {:queen, color})
  end

  defp place_king(board, color, square) do
    Map.put(board, square, {:king, color})
  end

  @doc """
  Get all legal moves for a piece at a given square
  """
  def get_legal_moves(board, square) do
    case Map.get(board.squares, square) do
      nil -> []
      {:pawn, color} -> pawn_moves(board, square, color)
      {:rook, color} -> rook_moves(board, square, color)
      {:knight, color} -> knight_moves(board, square, color)
      {:bishop, color} -> bishop_moves(board, square, color)
      {:queen, color} -> queen_moves(board, square, color)
      {:king, color} -> king_moves(board, square, color)
    end
  end

  defp pawn_moves(board, square, color) do
    direction = if color == :white, do: -8, else: 8
    forward = square + direction

    moves = if Map.get(board.squares, forward) == nil, do: [forward], else: []

    # Capture moves
    left_capture = forward - 1
    right_capture = forward + 1

    captures =
      Enum.filter([left_capture, right_capture], fn sq ->
        case Map.get(board.squares, sq) do
          {_, ^color} -> false
          {_, _} -> true
          nil -> false
        end
      end)

    moves ++ captures
  end

  defp rook_moves(board, square, color) do
    directions = [-8, 8, -1, 1]
    get_sliding_moves(board, square, color, directions)
  end

  defp bishop_moves(board, square, color) do
    directions = [-9, -7, 7, 9]
    get_sliding_moves(board, square, color, directions)
  end

  defp queen_moves(board, square, color) do
    directions = [-8, 8, -1, 1, -9, -7, 7, 9]
    get_sliding_moves(board, square, color, directions)
  end

  defp knight_moves(board, square, color) do
    offsets = [-17, -15, -10, -6, 6, 10, 15, 17]

    Enum.filter(offsets, fn offset ->
      target = square + offset
      valid_knight_move?(square, target, board.squares, color)
    end)
  end

  defp king_moves(board, square, color) do
    offsets = [-9, -8, -7, -1, 1, 7, 8, 9]

    Enum.filter(offsets, fn offset ->
      target = square + offset
      valid_square?(target) and not occupied_by_ally?(board.squares, target, color)
    end)
  end

  defp get_sliding_moves(board, square, color, directions) do
    Enum.reduce(directions, [], fn direction, moves ->
      get_direction_moves(board, square, color, direction) ++ moves
    end)
  end

  defp get_direction_moves(board, square, color, direction, moves \\ []) do
    target = square + direction
    
    unless valid_square?(target) do
      moves
    else
      case Map.get(board.squares, target) do
        nil -> get_direction_moves(board, target, color, direction, [target | moves])
        {_, ^color} -> moves
        {_, _} -> [target | moves]
      end
    end
  end

  defp valid_square?(square), do: square >= 0 and square < 64

  defp valid_knight_move?(from, to, squares, color) do
    valid_square?(to) and not occupied_by_ally?(squares, to, color)
  end

  defp occupied_by_ally?(squares, square, color) do
    case Map.get(squares, square) do
      {_, ^color} -> true
      _ -> false
    end
  end

  @doc """
  Make a move on the board
  """
  def make_move(board, from, to) do
    case Map.get(board.squares, from) do
      nil ->
        {:error, "No piece at source square"}

      {piece_type, color} ->
        if board.turn != color do
          {:error, "Not your turn"}
        else
          new_squares = board.squares |> Map.put(to, {piece_type, color}) |> Map.put(from, nil)

          {:ok,
           %{
             board
             | squares: new_squares,
               move_history: [{{from, to}, {piece_type, color}} | board.move_history],
               turn: opposite_color(board.turn)
           }}
        end
    end
  end

  defp opposite_color(:white), do: :black
  defp opposite_color(:black), do: :white
end