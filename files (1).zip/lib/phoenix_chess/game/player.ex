defmodule PhoenixChess.Game.Player do
  @moduledoc """
  Represents a chess player (human or AI)
  """

  defstruct id: nil, name: "", color: :white, type: :human, rating: 1600

  def new(id, name, color, type \\ :human) do
    %__MODULE__{
      id: id,
      name: name,
      color: color,
      type: type,
      rating: 1600
    }
  end

  def is_human?(%__MODULE__{type: :human}), do: true
  def is_human?(_), do: false

  def is_ai?(%__MODULE__{type: :ai}), do: true
  def is_ai?(_), do: false
end