defmodule PhoenixChess.Game.GameManager do
  @moduledoc """
  Manages active games and multiplayer state
  """

  alias PhoenixChess.Game.Board
  alias PhoenixChess.Game.Player
  alias PhoenixChess.AI.Engine

  defstruct id: nil,
            board: nil,
            white_player: nil,
            black_player: nil,
            status: :active,
            created_at: nil

  def new(game_id, white_player_name, black_player_type \\ :human) do
    %__MODULE__{
      id: game_id,
      board: Board.new(),
      white_player: Player.new(UUID.uuid4(), white_player_name, :white, :human),
      black_player:
        Player.new(UUID.uuid4(), "AI Engine", :black, black_player_type),
      status: :active,
      created_at: DateTime.utc_now()
    }
  end

  @doc """
  Make a move in the game
  """
  def make_move(game, from, to) do
    case Board.make_move(game.board, from, to) do
      {:ok, new_board} ->
        game = %{game | board: new_board}

        # If black is AI, make AI move
        if game.black_player.type == :ai do
          ai_move = Engine.best_move(game.board)
          case ai_move do
            {ai_from, ai_to} ->
              case Board.make_move(game.board, ai_from, ai_to) do
                {:ok, ai_board} ->
                  {:ok, %{game | board: ai_board}}

                _ ->
                  {:ok, game}
              end

            _ ->
              {:ok, game}
          end
        else
          {:ok, game}
        end

      error ->
        error
    end
  end

  @doc """
  Get current state of the game for display
  """
  def game_state(game) do
    %{
      id: game.id,
      board: game.board.squares,
      turn: game.board.turn,
      white_player: game.white_player,
      black_player: game.black_player,
      status: game.status,
      move_history: game.board.move_history
    }
  end
end