defmodule PhoenixChess.AI.Engine do
  @moduledoc """
  AI chess engine using Minimax algorithm with alpha-beta pruning
  """

  alias PhoenixChess.Game.Board
  alias PhoenixChess.AI.Evaluator

  @max_depth 4

  @doc """
  Find the best move for a given board position
  """
  def best_move(board, depth \\ @max_depth) do
    board.squares
    |> get_all_moves(board.turn)
    |> Enum.map(fn {from, to} ->
      case Board.make_move(board, from, to) do
        {:ok, new_board} ->
          score = minimax(new_board, depth - 1, -1000, 1000, false, board.turn)
          {{from, to}, score}

        _ ->
          {{from, to}, -1000}
      end
    end)
    |> Enum.max_by(fn {_move, score} -> score end)
    |> elem(0)
  end

  defp minimax(board, depth, alpha, beta, is_maximizing, ai_color) do
    if depth == 0 do
      Evaluator.evaluate(board, ai_color)
    else
      if is_maximizing do
        maximize(board, depth, alpha, beta, ai_color)
      else
        minimize(board, depth, alpha, beta, ai_color)
      end
    end
  end

  defp maximize(board, depth, alpha, beta, ai_color) do
    board.squares
    |> get_all_moves(board.turn)
    |> Enum.reduce({alpha, beta}, fn {from, to}, {alpha, beta} ->
      case Board.make_move(board, from, to) do
        {:ok, new_board} ->
          score = minimax(new_board, depth - 1, alpha, beta, false, ai_color)
          alpha = max(alpha, score)
          if beta <= alpha, do: throw(:cutoff)
          {alpha, beta}

        _ ->
          {alpha, beta}
      end
    end)
    |> elem(0)
  catch
    :cutoff -> beta
  end

  defp minimize(board, depth, alpha, beta, ai_color) do
    board.squares
    |> get_all_moves(board.turn)
    |> Enum.reduce({alpha, beta}, fn {from, to}, {alpha, beta} ->
      case Board.make_move(board, from, to) do
        {:ok, new_board} ->
          score = minimax(new_board, depth - 1, alpha, beta, true, ai_color)
          beta = min(beta, score)
          if beta <= alpha, do: throw(:cutoff)
          {alpha, beta}

        _ ->
          {alpha, beta}
      end
    end)
    |> elem(1)
  catch
    :cutoff -> alpha
  end

  defp get_all_moves(squares, color) do
    for square <- 0..63,
        {piece_type, piece_color} <- [Map.get(squares, square)],
        piece_color == color,
        to <- Board.get_legal_moves(%Board{squares: squares}, square) do
      {square, to}
    end
  end
end