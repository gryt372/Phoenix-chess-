defmodule PhoenixChess.AI.Evaluator do
  @moduledoc """
  Evaluates board positions for the AI
  """

  @piece_values %{
    pawn: 1,
    knight: 3,
    bishop: 3,
    rook: 5,
    queen: 9,
    king: 0
  }

  @doc """
  Evaluate a board position from the AI's perspective
  """
  def evaluate(board, ai_color) do
    material_score = count_material(board.squares, ai_color)
    position_score = count_positions(board.squares, ai_color)

    material_score + position_score
  end

  defp count_material(squares, ai_color) do
    Enum.reduce(squares, 0, fn {_square, piece}, acc ->
      case piece do
        {piece_type, color} ->
          value = Map.get(@piece_values, piece_type, 0)
          if color == ai_color, do: acc + value, else: acc - value

        nil ->
          acc
      end
    end)
  end

  defp count_positions(squares, ai_color) do
    # Bonus for controlling center squares
    center_squares = [27, 28, 35, 36]

    Enum.reduce(center_squares, 0, fn square, acc ->
      case Map.get(squares, square) do
        {_piece_type, color} when color == ai_color -> acc + 0.5
        {_piece_type, _color} -> acc - 0.5
        nil -> acc
      end
    end)
  end
end