defmodule PhoenixChessWeb.GameChannel do
  use PhoenixChessWeb, :channel

  alias PhoenixChess.Game.GameManager

  @impl true
  def join("game:" <> game_id, payload, socket) do
    if authorized?(payload) do
      send(self(), :after_join)
      {:ok, assign(socket, :game_id, game_id)}
    else
      {:error, %{reason: "unauthorized"}}
    end
  end

  @impl true
  def handle_info(:after_join, socket) do
    game_id = socket.assigns.game_id
    game = get_game(game_id)

    broadcast(socket, "game_state", GameManager.game_state(game))
    {:noreply, socket}
  end

  @impl true
  def handle_in("move", %{"from" => from, "to" => to}, socket) do
    game_id = socket.assigns.game_id
    game = get_game(game_id)

    case GameManager.make_move(game, from, to) do
      {:ok, updated_game} ->
        store_game(game_id, updated_game)
        broadcast(socket, "game_state", GameManager.game_state(updated_game))
        {:reply, :ok, socket}

      {:
