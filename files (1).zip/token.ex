defmodule PhoenixChess.Auth.Token do
  use Joken.Config

  def token_config do
    default_claims(skip: [:aud])
    |> add_claim("iss", fn -> "phoenix_chess" end, &is_binary/1)
  end
end