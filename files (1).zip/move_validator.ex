defmodule PhoenixChess.MoveValidator do
  @moduledoc """
  Validates chess moves according to standard chess rules
  """

  alias PhoenixChess.Board

  def valid_move?(board, from, to) do
    case Board.get_piece(board, from) do
      nil -> false
      {color, piece_type} ->
        if board.turn == color do
          case piece_type do
            :pawn -> valid_pawn_move?(board, from, to, color)
            :knight -> valid_knight_move?(from, to)
            :bishop -> valid_bishop_move?(board, from, to)
            :rook -> valid_rook_move?(board, from, to)
            :queen -> valid_queen_move?(board, from, to)
            :king -> valid_king_move?(board, from, to, color)
            _ -> false
          end
        else
          false
        end
    end
  end

  defp valid_pawn_move?(board, {fx, fy}, {tx, ty}, color) do
    direction = if color == :white, do: 1, else: -1
    target_piece = Board.get_piece(board, {tx, ty})

    cond do
      # Standard forward move
      fx == tx and target_piece == nil ->
        if fy + direction == ty, do: true, else: false

      # Initial two-square move
      (color == :white and fy == 1 and fy + 2 == ty and fx == tx) or
      (color == :black and fy == 6 and fy - 2 == ty and fx == tx) ->
        Board.get_piece(board, {tx, fy + direction}) == nil and target_piece == nil

      # Capture diagonally
      abs(fx - tx) == 1 and fy + direction == ty and target_piece != nil ->
        elem(target_piece, 0) != color

      # En passant
      board.en_passant_target == {tx, ty} and abs(fx - tx) == 1 ->
        true

      true -> false
    end
  end

  defp valid_knight_move?({fx, fy}, {tx, ty}) do
    dx = abs(fx - tx)
    dy = abs(fy - ty)
    (dx == 2 and dy == 1) or (dx == 1 and dy == 2)
  end

  defp valid_bishop_move?(board, {fx, fy}, {tx, ty}) do
    if abs(fx - tx) == abs(fy - ty) and {fx, fy} != {tx, ty} do
      path_clear?(board, {fx, fy}, {tx, ty})
    else
      false
    end
  end

  defp valid_rook_move?(board, {fx, fy}, {tx, ty}) do
    if (fx == tx or fy == ty) and {fx, fy} != {tx, ty} do
      path_clear?(board, {fx, fy}, {tx, ty})
    else
      false
    end
  end

  defp valid_queen_move?(board, from, to) do
    valid_rook_move?(board, from, to) or valid_bishop_move?(board, from, to)
  end

  defp valid_king_move?(board, {fx, fy}, {tx, ty}, color) do
    if abs(fx - tx) <= 1 and abs(fy - ty) <= 1 and {fx, fy} != {tx, ty} do
      true
    else
      # Castling
      castling_move?(board, {fx, fy}, {tx, ty}, color)
    end
  end

  defp castling_move?(board, {4, fy}, {tx, ty}, color) when fy == ty do
    # TODO: Implement castling logic
    false
  end

  defp castling_move?(_, _, _, _), do: false

  defp path_clear?(board, {fx, fy}, {tx, ty}) do
    dx = cond do
      tx > fx -> 1
      tx < fx -> -1
      true -> 0
    end

    dy = cond do
      ty > fy -> 1
      ty < fy -> -1
      true -> 0
    end

    path = generate_path({fx + dx, fy + dy}, {tx, ty}, dx, dy, [])

    Enum.all?(path, fn square ->
      Board.get_piece(board, square) == nil
    end)
  end

  defp generate_path({x, y}, {tx, ty}, _dx, _dy, acc) when x == tx and y == ty do
    Enum.reverse(acc)
  end

  defp generate_path({x, y}, {tx, ty}, dx, dy, acc) do
    generate_path({x + dx, y + dy}, {tx, ty}, dx, dy, [{x, y} | acc])
  end
end