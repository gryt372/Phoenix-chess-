defmodule PhoenixChess.Chat.Message do
  use Ecto.Schema
  import Ecto.Changeset

  schema "chat_messages" do
    field :content, :string
    field :is_spectator, :boolean, default: false

    belongs_to :user, PhoenixChess.Accounts.User
    belongs_to :game, PhoenixChess.Games.Game

    timestamps()
  end

  def changeset(message, attrs) do
    message
    |> cast(attrs, [:content, :is_spectator, :user_id, :game_id])
    |> validate_required([:content, :user_id, :game_id])
    |> validate_length(:content, min: 1, max: 500)
  end
end