defmodule PhoenixChess.AI.Evaluator do
  @moduledoc """
  Evaluates board positions for AI decision making
  """

  @piece_values %{
    pawn: 1,
    knight: 3,
    bishop: 3,
    rook: 5,
    queen: 9,
    king: 10000
  }

  def evaluate(board) do
    white_score = score_position(board, :white)
    black_score = score_position(board, :black)
    white_score - black_score
  end

  defp score_position(board, color) do
    pieces = board.squares

    Enum.reduce(pieces, 0, fn {{x, y}, {piece_color, piece_type}}, acc ->
      if piece_color == color do
        piece_value = @piece_values[piece_type] || 0
        position_bonus = get_position_bonus(piece_type, x, y, color)
        acc + piece_value + position_bonus
      else
        acc
      end
    end)
  end

  defp get_position_bonus(:pawn, x, y, color) do
    center_distance = min(abs(x - 3.5), abs(x - 4.5))
    bonus = 0.5 * (7 - center_distance)

    if color == :white and y > 4, do: bonus * 1.5, else: bonus
  end

  defp get_position_bonus(:knight, x, y, _color) do
    center_distance = min(abs(x - 3.5), abs(x - 4.5))
    0.1 * (7 - center_distance)
  end

  defp get_position_bonus(_, _, _, _), do: 0
end