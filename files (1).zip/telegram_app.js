import { Socket } from "phoenix"

class TelegramChessApp {
  constructor() {
    this.tg = window.Telegram.WebApp
    this.socket = null
    this.gameChannel = null
    this.lobbyChannel = null
    this.userId = null
    this.token = null
    this.currentGame = null
    this.selectedSquare = null
    this.validMoves = []

    this.init()
  }

  init() {
    // Initialize Telegram WebApp
    this.tg.ready()
    this.tg.expand()

    // Setup UI buttons
    this.setupButtons()

    // Authenticate with Telegram
    this.authenticateWithTelegram()
  }

  setupButtons() {
    this.tg.MainButton.text = "Start Game"
    this.tg.MainButton.onClick(() => this.showGameModes())

    this.tg.BackButton.onClick(() => this.goBack())
  }

  async authenticateWithTelegram() {
    try {
      const initData = this.tg.initData

      const response = await fetch("/api/auth/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ initData })
      })

      const data = await response.json()

      if (data.success) {
        this.userId = data.user.id
        this.token = data.token
        this.connectWebSocket()
        this.showLobby()
      } else {
        console.error("Auth failed:", data.error)
        this.showError(data.error)
      }
    } catch (error) {
      console.error("Authentication error:", error)
      this.showError("Authentication failed")
    }
  }

  connectWebSocket() {
    this.socket = new Socket("/socket", {
      params: { token: this.token }
    })

    this.socket.connect()

    // Join lobby channel
    this.lobbyChannel = this.socket.channel("lobby", { user_id: this.userId })

    this.lobbyChannel.on("active_games", payload => {
      this.displayActiveGames(payload.games)
    })

    this.lobbyChannel.on("leaderboard", payload => {
      this.displayLeaderboard(payload.players)
    })

    this.lobbyChannel.on("game_created", payload => {
      this.navigateToGame(payload.game_id)
    })

    this.lobbyChannel
      .join()
      .receive("ok", resp => console.log("Joined lobby", resp))
      .receive("error", resp => console.log("Lobby error", resp))
  }

  showGameModes() {
    this.clearContent()

    const html = `
      <div class="game-modes-container">
        <h2>Select Game Mode</h2>
        
        <div class="mode-selection">
          <button class="mode-btn" id="pvp-btn">
            <span class="icon">👥</span>
            <span>Play vs Friend</span>
          </button>
          
          <button class="mode-btn" id="pva-btn">
            <span class="icon">🤖</span>
            <span>Play vs AI</span>
          </button>
          
          <button class="mode-btn" id="random-btn">
            <span class="icon">🎲</span>
            <span>Random Opponent</span>
          </button>
        </div>

        <div class="time-controls">
          <h3>Select Time Control</h3>
          <div class="time-buttons">
            <button class="time-btn" data-type="bullet" data-time="60">Bullet (1m)</button>
            <button class="time-btn" data-type="blitz" data-time="300">Blitz (5m)</button>
            <button class="time-btn" data-type="rapid" data-time="600">Rapid (10m)</button>
            <button class="time-btn" data-type="classical" data-time="1800">Classical (30m)</button>
          </div>
        </div>
      </div>
    `

    this.appendContent(html)
    this.attachGameModeListeners()
  }

  attachGameModeListeners() {
    document.getElementById("pvp-btn").addEventListener("click", () => {
      this.showFriendsList()
    })

    document.getElementById("pva-btn").addEventListener("click", () => {
      this.startAIGame()
    })

    document.getElementById("random-btn").addEventListener("click", () => {
      this.searchRandomGame()
    })

    document.querySelectorAll(".time-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        document.querySelectorAll(".time-btn").forEach(b => b.classList.remove("active"))
        e.target.classList.add("active")
      })
    })
  }

  showLobby() {
    this.clearContent()

    const html = `
      <div class="lobby-container">
        <div class="lobby-header">
          <h1>♟ Phoenix Chess</h1>
          <p>Play Chess on Telegram</p>
        </div>

        <div class="lobby-stats">
          <div class="stat">
            <span class="label">Your Rating</span>
            <span class="value" id="user-elo">1600</span>
          </div>
          <div class="stat">
            <span class="label">Games Played</span>
            <span class="value" id="user-games">0</span>
          </div>
        </div>

        <button class="tg-button" id="start-game-btn">
          Start Playing
        </button>

        <div class="active-games">
          <h3>Live Games</h3>
          <div id="games-list"></div>
        </div>

        <div class="leaderboard">
          <h3>Top Players</h3>
          <div id="leaderboard-list"></div>
        </div>
      </div>
    `

    this.appendContent(html)

    document.getElementById("start-game-btn").addEventListener("click", () => {
      this.showGameModes()
    })

    this.loadUserProfile()
  }

  async loadUserProfile() {
    try {
      const response = await fetch("/api/user/profile", {
        headers: { "Authorization": `Bearer ${this.token}` }
      })

      const user = await response.json()

      document.getElementById("user-elo").textContent = user.elo
      document.getElementById("user-games").textContent = user.wins + user.losses + user.draws
    } catch (error) {
      console.error("Failed to load profile:", error)
    }
  }

  displayActiveGames(games) {
    const list = document.getElementById("games-list")
    if (!list) return

    list.innerHTML = games.slice(0, 5).map(game => `
      <div class="game-item">
        <div class="game-header">
          <span>${game.white.username}</span>
          <span class="vs">vs</span>
          <span>${game.black.username}</span>
        </div>
        <div class="game-rating">
          <span>${game.white.elo}</span>
          <span class="rating-sep">-</span>
          <span>${game.black.elo}</span>
        </div>
        <div class="game-type">${game.game_type}</div>
      </div>
    `).join("")
  }

  displayLeaderboard(players) {
    const list = document.getElementById("leaderboard-list")
    if (!list) return

    list.innerHTML = players.slice(0, 5).map((player, idx) => `
      <div class="leaderboard-item">
        <span class="rank">#${idx + 1}</span>
        <span class="name">${player.username}</span>
        <span class="rating">${player.elo}</span>
      </div>
    `).join("")
  }

  showChessboard(gameId) {
    this.clearContent()

    const html = `
      <div class="game-container">
        <div class="game-info">
          <div class="player white-player">
            <div class="player-name" id="white-name">White</div>
            <div class="player-rating" id="white-rating">1600</div>
            <div class="player-clock" id="white-clock">05:00</div>
          </div>

          <div class="turn-indicator" id="turn-indicator">White to Move</div>

          <div class="player black-player">
            <div class="player-name" id="black-name">Black</div>
            <div class="player-rating" id="black-rating">1600</div>
            <div class="player-clock" id="black-clock">05:00</div>
          </div>
        </div>

        <div class="chessboard" id="chessboard"></div>

        <div class="game-actions">
          <button id="resign-btn" class="action-btn resign">Resign</button>
          <button id="draw-btn" class="action-btn draw">Draw</button>
          <button id="takeback-btn" class="action-btn takeback">Takeback</button>
        </div>

        <div class="move-list" id="move-list"></div>
      </div>
    `

    this.appendContent(html)
    this.initializeChessboard(gameId)
    this.attachGameActions(gameId)
  }

  initializeChessboard(gameId) {
    const board = document.getElementById("chessboard")
    board.innerHTML = ""

    // Create 8x8 board
    for (let rank = 7; rank >= 0; rank--) {
      for (let file = 0; file < 8; file++) {
        const square = document.createElement("div")
        const isLight = (file + rank) % 2 === 0
        square.className = `square ${isLight ? "light" : "dark"}`
        square.id = `square-${file}-${rank}`

        square.addEventListener("click", () => this.handleSquareClick(file, rank, gameId))

        board.appendChild(square)
      }
    }

    // Load game state
    this.joinGameChannel(gameId)
  }

  joinGameChannel(gameId) {
    this.gameChannel = this.socket.channel(`game:${gameId}`, { user_id: this.userId })

    this.gameChannel.on("game_state", payload => {
      this.updateGameUI(payload)
    })

    this.gameChannel.on("move_made", payload => {
      this.updateBoard(payload)
      this.addMoveToHistory(payload.san)
    })

    this.gameChannel.on("game_over", payload => {
      this.showGameOver(payload)
    })

    this.gameChannel.on("message", payload => {
      this.displayChatMessage(payload)
    })

    this.gameChannel
      .join()
      .receive("ok", resp => console.log("Joined game", resp))
      .receive("error", resp => console.log("Game error", resp))
  }

  handleSquareClick(file, rank, gameId) {
    const squareId = `${file}-${rank}`

    if (this.selectedSquare === null) {
      // Select a piece
      const square = document.getElementById(`square-${squareId}`)
      const piece = square.querySelector(".piece")

      if (piece) {
        this.selectedSquare = squareId
        square.classList.add("selected")
        this.calculateValidMoves(file, rank, gameId)
      }
    } else {
      // Move the piece
      this.makeMove(this.selectedSquare, squareId, gameId)
      this.selectedSquare = null
      document.querySelectorAll(".square").forEach(sq => sq.classList.remove("selected", "valid-move"))
    }
  }

  makeMove(from, to, gameId) {
    const [fromFile, fromRank] = from.split("-").map(Number)
    const [toFile, toRank] = to.split("-").map(Number)

    this.gameChannel.push("move", {
      from: `${fromFile},${fromRank}`,
      to: `${toFile},${toRank}`,
      promotion: "q"
    })
  }

  updateGameUI(payload) {
    document.getElementById("white-name").textContent = payload.white_player.username
    document.getElementById("white-rating").textContent = payload.white_player.elo
    document.getElementById("black-name").textContent = payload.black_player.username
    document.getElementById("black-rating").textContent = payload.black_player.elo
    document.getElementById("turn-indicator").textContent = 
      payload.turn === "white" ? "White to Move" : "Black to Move"

    this.updateClocks(payload.white_player.clock, payload.black_player.clock)
  }

  updateBoard(payload) {
    // Update piece positions based on move
    console.log("Move made:", payload.from, "to", payload.to)
  }

  updateClocks(whiteClock, blackClock) {
    document.getElementById("white-clock").textContent = this.formatTime(whiteClock)
    document.getElementById("black-clock").textContent = this.formatTime(blackClock)
  }

  formatTime(seconds) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  addMoveToHistory(san) {
    const moveList = document.getElementById("move-list")
    const move = document.createElement("span")
    move.className = "move"
    move.textContent = san
    moveList.appendChild(move)
  }

  attachGameActions(gameId) {
    document.getElementById("resign-btn").addEventListener("click", () => {
      if (confirm("Are you sure you want to resign?")) {
        this.gameChannel.push("resign")
      }
    })

    document.getElementById("draw-btn").addEventListener("click", () => {
      this.gameChannel.push("offer_draw")
    })

    document.getElementById("takeback-btn").addEventListener("click", () => {
      this.gameChannel.push("request_takeback")
    })
  }

  showGameOver(payload) {
    const message = `Game Over: ${payload.result} (${payload.termination})`
    alert(message)
    this.showLobby()
  }

  calculateValidMoves(file, rank, gameId) {
    // TODO: Calculate valid moves from backend
  }

  displayChatMessage(payload) {
    console.log(`${payload.username}: ${payload.message}`)
  }

  navigateToGame(gameId) {
    this.showChessboard(gameId)
  }

  startAIGame() {
    const gameId = this.generateGameId()
    const attrs = {
      game_id: gameId,
      white_user_id: this.userId,
      black_user_id: "ai",
      game_type: "blitz",
      time_control: 300,
      status: "active",
      white_clock: 300,
      black_clock: 300
    }

    // Create game and navigate to it
    this.showChessboard(gameId)
  }

  searchRandomGame() {
    this.lobbyChannel.push("search_game", { game_type: "blitz", time_control: 300 })
    this.showSearching()
  }

  showSearching() {
    this.clearContent()
    this.appendContent(`
      <div class="searching-container">
        <h2>Searching for Opponent...</h2>
        <div class="spinner"></div>
        <button id="cancel-search">Cancel</button>
      </div>
    `)

    document.getElementById("cancel-search").addEventListener("click", () => {
      this.lobbyChannel.push("cancel_search")
      this.showLobby()
    })
  }

  showFriendsList() {
    // TODO: Implement friends list UI
    this.showLobby()
  }

  showError(message) {
    alert(`Error: ${message}`)
  }

  goBack() {
    this.showLobby()
  }

  clearContent() {
    document.body.innerHTML = ""
  }

  appendContent(html) {
    document.body.innerHTML += html
  }

  generateGameId() {
    return Math.random().toString(36).substr(2, 9)
  }
}

// Initialize app when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  new TelegramChessApp()
})

export { TelegramChessApp }