defmodule PhoenixChessWeb.Router do
  use PhoenixChessWeb, :router

  pipeline :browser do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_live_flash
    plug :put_root_layout, {PhoenixChessWeb.LayoutView, :root}
    plug :protect_from_forgery
    plug :put_secure_browser_headers
  end

  pipeline :api do
    plug :accepts, ["json"]
    plug CORSPlug
  end

  pipeline :api_auth do
    plug :api
    plug PhoenixChessWeb.Plugs.AuthPlug
  end

  scope "/", PhoenixChessWeb do
    pipe_through :browser

    get "/", PageController, :index
    get "/game/:id", GameController, :show
  end

  scope "/api", PhoenixChessWeb do
    pipe_through :api

    post "/auth/telegram", TelegramAuthController, :login
    post "/auth/logout", TelegramAuthController, :logout
  end

  scope "/api", PhoenixChessWeb do
    pipe_through :api_auth

    get "/user/profile", UserController, :profile
    get "/user/games", UserController, :games
    get "/user/stats", UserController, :stats
    put "/user/settings", UserController, :update_settings
    
    get "/leaderboard", LeaderboardController, :index
    get "/games/active", GameController, :active_games
  end
end