defmodule PhoenixChess.Games do
  import Ecto.Query
  alias PhoenixChess.Repo
  alias PhoenixChess.Games.Game
  alias PhoenixChess.Games.Move

  def get_game(id), do: Repo.get(Game, id)

  def get_game_by_game_id(game_id) do
    Repo.get_by(Game, game_id: game_id)
    |> Repo.preload([:white_user, :black_user, :moves])
  end

  def get_active_games(limit \\ 20) do
    from(g in Game,
      where: g.status == "active",
      where: g.is_spectatable == true,
      order_by: [desc: g.inserted_at],
      limit: ^limit,
      preload: [:white_user, :black_user]
    )
    |> Repo.all()
  end

  def get_user_games(user_id, limit \\ 50) do
    from(g in Game,
      where: g.white_user_id == ^user_id or g.black_user_id == ^user_id,
      order_by: [desc: g.inserted_at],
      limit: ^limit,
      preload: [:white_user, :black_user]
    )
    |> Repo.all()
  end

  def create_game(attrs) do
    %Game{}
    |> Game.changeset(attrs)
    |> Repo.insert()
  end

  def update_game(game, attrs) do
    game
    |> Game.changeset(attrs)
    |> Repo.update()
  end

  def add_move(game_id, move_attrs) do
    %Move{}
    |> Move.changeset(Map.merge(move_attrs, %{game_id: game_id}))
    |> Repo.insert()
  end

  def get_game_moves(game_id) do
    from(m in Move,
      where: m.game_id == ^game_id,
      order_by: [asc: m.sequence]
    )
    |> Repo.all()
  end
end