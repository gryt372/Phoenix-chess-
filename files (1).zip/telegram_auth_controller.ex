defmodule PhoenixChessWeb.TelegramAuthController do
  use PhoenixChessWeb, :controller
  require Logger

  alias PhoenixChess.Telegram.Auth
  alias PhoenixChess.Accounts

  def login(conn, %{"initData" => init_data_raw}) do
    case Auth.verify_init_data(init_data_raw) do
      {:ok, telegram_user} ->
        case Accounts.create_user_from_telegram(telegram_user) do
          {:ok, user} ->
            # Generate JWT token
            token = generate_token(user)

            json(conn, %{
              success: true,
              user: %{
                id: user.id,
                username: user.username,
                avatar: user.avatar_url,
                elo: user.elo
              },
              token: token
            })

          {:error, reason} ->
            json(conn, %{success: false, error: inspect(reason)})
        end

      {:error, reason} ->
        json(conn, %{success: false, error: reason})
    end
  end

  def logout(conn, _params) do
    json(conn, %{success: true})
  end

  defp generate_token(user) do
    # Use Joken for JWT token generation
    {:ok, token, _claims} = PhoenixChess.Auth.Token.generate_and_sign(%{"user_id" => user.id})
    token
  end
end