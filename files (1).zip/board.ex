defmodule PhoenixChess.Board do
  @moduledoc """
  Manages the chess board state and piece positions
  """

  defstruct [
    :squares,
    :white_king_pos,
    :black_king_pos,
    :white_castling,
    :black_castling,
    :en_passant_target,
    :halfmove_clock,
    :fullmove_number,
    :turn
  ]

  @pieces %{
    "p" => :pawn,
    "n" => :knight,
    "b" => :bishop,
    "r" => :rook,
    "q" => :queen,
    "k" => :king
  }

  def new() do
    %PhoenixChess.Board{
      squares: initial_position(),
      white_king_pos: {4, 0},
      black_king_pos: {4, 7},
      white_castling: %{kingside: true, queenside: true},
      black_castling: %{kingside: true, queenside: true},
      en_passant_target: nil,
      halfmove_clock: 0,
      fullmove_number: 1,
      turn: :white
    }
  end

  defp initial_position do
    %{
      {0, 0} => {:white, :rook}, {1, 0} => {:white, :knight},
      {2, 0} => {:white, :bishop}, {3, 0} => {:white, :queen},
      {4, 0} => {:white, :king}, {5, 0} => {:white, :bishop},
      {6, 0} => {:white, :knight}, {7, 0} => {:white, :rook},
      {0, 1} => {:white, :pawn}, {1, 1} => {:white, :pawn},
      {2, 1} => {:white, :pawn}, {3, 1} => {:white, :pawn},
      {4, 1} => {:white, :pawn}, {5, 1} => {:white, :pawn},
      {6, 1} => {:white, :pawn}, {7, 1} => {:white, :pawn},
      {0, 7} => {:black, :rook}, {1, 7} => {:black, :knight},
      {2, 7} => {:black, :bishop}, {3, 7} => {:black, :queen},
      {4, 7} => {:black, :king}, {5, 7} => {:black, :bishop},
      {6, 7} => {:black, :knight}, {7, 7} => {:black, :rook},
      {0, 6} => {:black, :pawn}, {1, 6} => {:black, :pawn},
      {2, 6} => {:black, :pawn}, {3, 6} => {:black, :pawn},
      {4, 6} => {:black, :pawn}, {5, 6} => {:black, :pawn},
      {6, 6} => {:black, :pawn}, {7, 6} => {:black, :pawn}
    }
  end

  def get_piece(board, {x, y}) do
    board.squares[{x, y}]
  end

  def set_piece(board, {x, y}, piece) do
    %{board | squares: Map.put(board.squares, {x, y}, piece)}
  end

  def clear_piece(board, {x, y}) do
    %{board | squares: Map.delete(board.squares, {x, y})}
  end

  def is_valid_square?({x, y}) do
    x >= 0 and x < 8 and y >= 0 and y < 8
  end

  def all_pieces(board) do
    board.squares
  end
end