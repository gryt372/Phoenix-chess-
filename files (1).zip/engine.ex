defmodule PhoenixChess.AI.Engine do
  @moduledoc """
  Chess AI engine using minimax algorithm with alpha-beta pruning
  """

  alias PhoenixChess.Board
  alias PhoenixChess.MoveValidator
  alias PhoenixChess.AI.Evaluator

  def find_best_move(board, depth \\ 3) do
    board_moves = get_all_legal_moves(board)

    {best_move, _score} =
      Enum.max_by(board_moves, fn {_from, _to} ->
        {_from, _to, minimax(board, depth - 1, true, -10000, 10000)}
      end, fn {_a, _b, score_a}, {_c, _d, score_b} ->
        score_a >= score_b
      end)

    {best_move, _score}
  end

  defp minimax(board, 0, _is_maximizing, _alpha, _beta) do
    Evaluator.evaluate(board)
  end

  defp minimax(board, depth, is_maximizing, alpha, beta) do
    moves = get_all_legal_moves(board)

    if is_maximizing do
      Enum.reduce(moves, alpha, fn {_from, _to}, current_alpha ->
        # TODO: Execute move and recurse
        current_alpha
      end)
    else
      Enum.reduce(moves, beta, fn {_from, _to}, current_beta ->
        # TODO: Execute move and recurse
        current_beta
      end)
    end
  end

  defp get_all_legal_moves(board) do
    pieces = Board.all_pieces(board)

    Enum.flat_map(pieces, fn {{x, y}, _piece} ->
      Enum.flat_map(0..7, fn tx ->
        Enum.flat_map(0..7, fn ty ->
          if MoveValidator.valid_move?(board, {x, y}, {tx, ty}) do
            [{{x, y}, {tx, ty}}]
          else
            []
          end
        end)
      end)
    end)
  end
end